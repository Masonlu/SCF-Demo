# -*- coding: utf-8 -*-

class CIFile(str):
    """image File"""
    pass

class CIBuffer(bytes):
    """image content"""
    pass

class CIUrl(str):
    """image url"""
    pass

class CIFiles(list):
    pass

class CIBuffers(list):
    """image content"""
    pass

class CIUrls(list):
    """image url"""
    pass

